// Sample showing for loop

public class For {

    public static void main(String args[]) {
        for (int r = 1; r<100; r++) {
            System.out.println(r);
        }
    
        System.out.println();

        for (int r = 50; r > 0; r-=5) {
            System.out.print(r + " ");
        }
    }
}
