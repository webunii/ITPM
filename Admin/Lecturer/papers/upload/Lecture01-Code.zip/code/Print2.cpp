// This program demos use of simple variables and printing them

#include <iostream>
using namespace std;

int main() {

   int no = 50;
   long population = 70000000;
   double salary = 4500.34;
   float rate = 34.5f;

   cout << "no = " << no << endl;
   cout << "population = " << population << endl;
   cout << "salary = " << salary << endl;
   cout << "rate = " << rate << endl;
   
   return 0;
}
