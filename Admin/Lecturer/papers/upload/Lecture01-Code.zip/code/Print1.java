// Sample showing printing of lines

public class Print1 {

    public static void main(String args[]) {
        System.out.print("This is line 1");
        System.out.print(" still line 1");
        System.out.println(" lets move to the next line "); 
        System.out.println("finally line 2");
    }
}
