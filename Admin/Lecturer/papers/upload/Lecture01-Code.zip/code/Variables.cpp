// This program demos use of simple variables

#include <iostream>
using namespace std;

int main() {

   int no = 50;
   long population = 70000000;
   double salary = 4500.34;
   float rate = 34.5f;

   cout << no << endl;
   cout << population << endl;
   cout << salary << endl;
   cout << rate << endl;
   
   return 0;
}
