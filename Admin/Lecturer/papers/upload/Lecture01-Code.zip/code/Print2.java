// This program demos use of simple variables and printing them


public class Print2 {

    public static void main(String args[]) {

        int no = 50;
        long population = 70000000;
        double salary = 4500.34;
        float rate = 34.5f;

        System.out.println("no = " + no);
        System.out.println("population = " + population); 
        System.out.println("salary = " + salary);
        System.out.println("rate = " + rate); 
   
    }
}
