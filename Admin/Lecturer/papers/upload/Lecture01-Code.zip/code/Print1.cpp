// Sample showing printing of lines

#include <iostream>
using namespace std;

int main() {
   cout << "This is line 1";
   cout << " still line 1";
   cout << " lets move to the next line " << endl;
   cout << "finally line 2" << endl;
   return 0;
}
