package paper4b;

public class Employee {
	public int empID;
	public Employee next;
	
	public Employee(int id) {
		empID = id;
		next = null;
	}
	
	public void displayEmployee() {
		System.out.println("Employee ID : " + empID);
	}
}
