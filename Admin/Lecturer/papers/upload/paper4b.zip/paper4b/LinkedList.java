package paper4b;

public class LinkedList {
	private Employee first;
	
	public LinkedList() {
		first = null;
	}
	
	void InsertFirst(int id) {
		Employee newEmp = new Employee(id);
		newEmp.next = first;
		first = newEmp;		
	}
	
	void displayListForward() {
		System.out.println("List of Employees : ");
		Employee current = first;
		while(current != null) {
			current.displayEmployee();
			current = current.next;
		}
	}
	
	void deleteEmployees() {
		first = null;
	}
	
	
}
