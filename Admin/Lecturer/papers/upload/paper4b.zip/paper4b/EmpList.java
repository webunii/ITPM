package paper4b;
import java.util.*;

public class EmpList {

	public static void main(String[] args) {
		LinkedList empList = new LinkedList();
		
		Scanner sc = new Scanner(System.in);
		
		for(int i = 0; i < 5; i++) {
			System.out.println("Insert Employee ID");
			empList.InsertFirst(sc.nextInt());
		}
		
		empList.displayListForward();
		
		System.out.println("Delete all employees in Linked List");		
		empList.deleteEmployees();
		
		empList.displayListForward();
		

	}

}
